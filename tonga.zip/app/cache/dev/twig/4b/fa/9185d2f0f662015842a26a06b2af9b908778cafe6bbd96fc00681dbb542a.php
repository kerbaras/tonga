<?php

/* AdminBundle:Tarifas:new.html.twig */
class __TwigTemplate_4bfa9185d2f0f662015842a26a06b2af9b908778cafe6bbd96fc00681dbb542a extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = $this->env->loadTemplate("AdminBundle::layout.html.twig");

        $this->blocks = array(
            'pageContainer' => array($this, 'block_pageContainer'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "AdminBundle::layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 1
        $context["forms"] = $this->env->loadTemplate("AdminBundle:Functions:forms.html.twig");
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 5
    public function block_pageContainer($context, array $blocks = array())
    {
        // line 6
        echo "\t\t\t\t<!-- Page Heading -->
                <div class=\"row\">
                    <div class=\"col-lg-12\">
                        <h1 class=\"page-header\">
                            <i class=\"fa fa-group\"></i> Tarifas <small>Gestor de tarifas</small>
                        </h1>
                        <ol class=\"breadcrumb\">
                            <li>
                                <a href=\"";
        // line 14
        echo $this->env->getExtension('routing')->getPath("admin_clientes_homepage");
        echo "\"><i class=\"fa fa-group\"></i> Tarifas</a>
                            </li>
                            ";
        // line 16
        if (((isset($context["action"]) ? $context["action"] : $this->getContext($context, "action")) == "Agregar")) {
            // line 17
            echo "                            <li class=\"active\">
                                Nueva
                            </li>
                            ";
        } else {
            // line 21
            echo "                            <li>
                                <a href=\"";
            // line 22
            echo $this->env->getExtension('routing')->getPath("admin_clientes_homepage");
            echo "\">";
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["tarifa"]) ? $context["tarifa"] : $this->getContext($context, "tarifa")), "nombre", array()), "html", null, true);
            echo " (\$";
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["tarifa"]) ? $context["tarifa"] : $this->getContext($context, "tarifa")), "monto", array()), "html", null, true);
            echo ")</a>
                            </li>
                            <li class=\"active\">
                                Editar
                            </li>
                            ";
        }
        // line 28
        echo "                        </ol>

                        <div class=\"row\">
                            <div class=\"col-lg-12\">
                                <div class=\"panel panel-default\">
                                    <div class=\"panel-heading\">
                                        ";
        // line 34
        echo twig_escape_filter($this->env, (isset($context["action"]) ? $context["action"] : $this->getContext($context, "action")), "html", null, true);
        echo " una tarifa
                                    </div><!-- / .panel-heading -->
                                    <div class=\"panel-body\">
                                        <form class=\"form-horizontal\" role=\"form\" enctype=\"multipart/form-data\" method=\"post\">

                                          ";
        // line 39
        echo $context["forms"]->getinput("nombre", "Nombre", $this->getAttribute((isset($context["tarifa"]) ? $context["tarifa"] : $this->getContext($context, "tarifa")), "nombre", array()));
        echo "

                                          ";
        // line 41
        echo $context["forms"]->getinput("monto", "Monto", $this->getAttribute((isset($context["tarifa"]) ? $context["tarifa"] : $this->getContext($context, "tarifa")), "monto", array()), "number");
        echo "

                                          <div class=\"form-group\">
                                            <div class=\"col-sm-offset-2 col-sm-10\">
                                              <button type=\"submit\" class=\"btn btn-primary\">Guardar</button>
                                            </div>
                                          </div>
                                        </form>
                                    </div><!-- / .panel-body -->
                                </div><!-- / .panel -->
                            </div>
                        </div>
                    </div>
                </div>
                <!-- /.row -->
";
    }

    public function getTemplateName()
    {
        return "AdminBundle:Tarifas:new.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  93 => 41,  88 => 39,  80 => 34,  72 => 28,  59 => 22,  56 => 21,  50 => 17,  48 => 16,  43 => 14,  33 => 6,  30 => 5,  25 => 1,);
    }
}
