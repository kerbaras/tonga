<?php

/* AdminBundle:Functions:forms.html.twig */
class __TwigTemplate_85825c3af30d9b02b797ceaf12571e1308ef1165ac57eccd230373f250e54bcc extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
    }

    // line 1
    public function getinput($_name = null, $_text = null, $_value = null, $_type = null, $_classes = null)
    {
        $context = $this->env->mergeGlobals(array(
            "name" => $_name,
            "text" => $_text,
            "value" => $_value,
            "type" => $_type,
            "classes" => $_classes,
        ));

        $blocks = array();

        ob_start();
        try {
            // line 2
            echo "<div class=\"form-group\">
    <label for=\"";
            // line 3
            echo twig_escape_filter($this->env, (isset($context["name"]) ? $context["name"] : $this->getContext($context, "name")), "html", null, true);
            echo "\" class=\"col-md-2 control-label\">";
            echo twig_escape_filter($this->env, (isset($context["text"]) ? $context["text"] : $this->getContext($context, "text")), "html", null, true);
            echo "</label>
    <div class=\"col-md-10\"><input class=\"form-control ";
            // line 4
            echo twig_escape_filter($this->env, ((array_key_exists("classes", $context)) ? (_twig_default_filter((isset($context["classes"]) ? $context["classes"] : $this->getContext($context, "classes")), "")) : ("")), "html", null, true);
            echo "\" type=\"";
            echo twig_escape_filter($this->env, ((array_key_exists("type", $context)) ? (_twig_default_filter((isset($context["type"]) ? $context["type"] : $this->getContext($context, "type")), "text")) : ("text")), "html", null, true);
            echo "\" name=\"";
            echo twig_escape_filter($this->env, (isset($context["name"]) ? $context["name"] : $this->getContext($context, "name")), "html", null, true);
            echo "\" placeholder=\"";
            echo twig_escape_filter($this->env, (isset($context["text"]) ? $context["text"] : $this->getContext($context, "text")), "html", null, true);
            echo "\" value=\"";
            echo twig_escape_filter($this->env, (isset($context["value"]) ? $context["value"] : $this->getContext($context, "value")), "html", null, true);
            echo "\"></div>
</div>
";
        } catch (Exception $e) {
            ob_end_clean();

            throw $e;
        }

        return ('' === $tmp = ob_get_clean()) ? '' : new Twig_Markup($tmp, $this->env->getCharset());
    }

    public function getTemplateName()
    {
        return "AdminBundle:Functions:forms.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  45 => 4,  39 => 3,  36 => 2,  21 => 1,);
    }
}
