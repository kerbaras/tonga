<?php

// AdminBundle:Clientes:new.html.twig
return array (
  '2c3b0f2' => 
  array (
    0 => 
    array (
      0 => 'bundles/admin/css/plugins/dataTables.bootstrap.css',
    ),
    1 => 
    array (
      0 => 'cssrewrite',
    ),
    2 => 
    array (
      'output' => '_controller/css/2c3b0f2.css',
      'name' => '2c3b0f2',
      'debug' => NULL,
      'combine' => NULL,
      'vars' => 
      array (
      ),
    ),
  ),
  '869cab4' => 
  array (
    0 => 
    array (
      0 => '@AdminBundle/Resources/public/js/plugins/dataTables/jquery.dataTables.js',
      1 => '@AdminBundle/Resources/public/js/plugins/dataTables/dataTables.bootstrap.js',
    ),
    1 => 
    array (
    ),
    2 => 
    array (
      'output' => '_controller/js/869cab4.js',
      'name' => '869cab4',
      'debug' => NULL,
      'combine' => NULL,
      'vars' => 
      array (
      ),
    ),
  ),
);
