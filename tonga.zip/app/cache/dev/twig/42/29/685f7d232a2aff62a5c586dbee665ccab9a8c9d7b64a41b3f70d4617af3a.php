<?php

/* AdminBundle:Tarifas:index.html.twig */
class __TwigTemplate_4229685f7d232a2aff62a5c586dbee665ccab9a8c9d7b64a41b3f70d4617af3a extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = $this->env->loadTemplate("AdminBundle::layout.html.twig");

        $this->blocks = array(
            'pageContainer' => array($this, 'block_pageContainer'),
            'stylesheets' => array($this, 'block_stylesheets'),
            'javascripts' => array($this, 'block_javascripts'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "AdminBundle::layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 3
    public function block_pageContainer($context, array $blocks = array())
    {
        // line 4
        echo "\t\t\t\t<!-- Page Heading -->
                <div class=\"row\">
                    <div class=\"col-lg-12\">
                        <h1 class=\"page-header\">
                            <i class=\"fa fa-group\"></i>  Tarifas <small>Gestor de Tarifas</small>
                        </h1>
                        <ol class=\"breadcrumb\">
                            <li class=\"active\">
                                <i class=\"fa fa-group\"></i> Tarifas
                            </li>
                        </ol>

                        <div class=\"row\">
                            <div class=\"col-lg-12\">
                                <div class=\"panel panel-default\">
                                    <div class=\"panel-heading\">
                                        Tarifas

                                        <div class=\"pull-right\">
                                            <div class=\"btn-group\">
                                                <a href=\"";
        // line 24
        echo $this->env->getExtension('routing')->getPath("admin_tarifas_newpage");
        echo "\" class=\"btn btn-default btn-xs\"><i class=\"fa fa-plus\"></i> Agregar Tarifa</a>
                                            </div>
                                        </div>
                                    </div><!-- / .panel-heading -->
                                    <div class=\"panel-body\">
                                        <div class=\"table-responsive\">
                                            <table id=\"tableClientes\" class=\"table table-striped table-bordered table-hover datatable\">
                                                <thead>
                                                    <tr>
                                                        <th>Nombre</th>
                                                        <th>Monto</th>
                                                        <th>Clientes</th>
                                                        <th>Acciones</th>
                                                    </tr>
                                                </thead>
                                                <tbody>
                                                ";
        // line 40
        $context['_parent'] = (array) $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["tarifas"]) ? $context["tarifas"] : $this->getContext($context, "tarifas")));
        $context['_iterated'] = false;
        foreach ($context['_seq'] as $context["_key"] => $context["tarifa"]) {
            // line 41
            echo "                                                    <tr valign=\"middle\">
                                                        <td>";
            // line 42
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["tarifa"]) ? $context["tarifa"] : $this->getContext($context, "tarifa")), "nombre", array()), "html", null, true);
            echo "</td>
                                                        <td>";
            // line 43
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["tarifa"]) ? $context["tarifa"] : $this->getContext($context, "tarifa")), "monto", array()), "html", null, true);
            echo "</td>
                                                        <td>";
            // line 44
            echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute((isset($context["tarifa"]) ? $context["tarifa"] : $this->getContext($context, "tarifa")), "clientes", array()), "count", array()), "html", null, true);
            echo "</td>
                                                        <td align=\"center\">
                                                            <a href=\"#\" class=\"btn btn-info btn-circle\"><i class=\"fa fa-search\"></i></a>
                                                            <a href=\"";
            // line 47
            echo twig_escape_filter($this->env, $this->env->getExtension('routing')->getPath("admin_tarifas_editpage", array("id" => $this->getAttribute((isset($context["tarifa"]) ? $context["tarifa"] : $this->getContext($context, "tarifa")), "id", array()))), "html", null, true);
            echo "\" class=\"btn btn-warning btn-circle\"><i class=\"fa fa-edit\"></i></a>
                                                            <a href=\"javascript:eliminar('";
            // line 48
            echo twig_escape_filter($this->env, $this->env->getExtension('routing')->getPath("admin_tarifas_delete", array("id" => $this->getAttribute((isset($context["tarifa"]) ? $context["tarifa"] : $this->getContext($context, "tarifa")), "id", array()))), "html", null, true);
            echo "');\" class=\"btn btn-danger btn-circle\"><i class=\"fa fa-trash\"></i></a>
                                                        </td>
                                                    </tr>
                                                ";
            $context['_iterated'] = true;
        }
        if (!$context['_iterated']) {
            // line 52
            echo "                                                    <tr class=\"warning\">
                                                        <td colspan=\"6\"><strong>No se encontraron Tarifas</strong></td>
                                                    </tr>
                                                ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['tarifa'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 56
        echo "                                                </tbody>
                                            </table>
                                        </div>
                                    </div><!-- / .panel-body -->
                                </div><!-- / .panel -->
                            </div>
                        </div>
                    </div>
                </div>
                <!-- /.row -->
                
                <!-- Modal Eliminar -->
                <div class=\"modal fade\" id=\"eliminarModal\" tabindex=\"-1\" role=\"dialog\" aria-labelledby=\"eliminarModalLabel\" aria-hidden=\"true\">
                  <div class=\"modal-dialog\">
                    <div class=\"modal-content\">
                      <div class=\"modal-header\">
                        <button type=\"button\" class=\"close\" data-dismiss=\"modal\"><span aria-hidden=\"true\">&times;</span><span class=\"sr-only\">Cerrar</span></button>
                        <h4 class=\"modal-title\" id=\"eliminarModalLabel\">Eliminar Tarifa</h4>
                      </div>
                      <div class=\"modal-body\">
                        <p>¿Esta seguro que desea eliminar el tarifa?</p>
                      </div>
                      <div class=\"modal-footer\">
                        <button type=\"button\" class=\"btn btn-default\" data-dismiss=\"modal\">Cancelar</button>
                        <a href=\"\" class=\"btn btn-danger\">Eliminar</a>
                      </div>
                    </div><!-- /.modal-content -->
                  </div><!-- /.modal-dialog -->
                </div><!-- /.modal Eliminar -->

";
    }

    // line 88
    public function block_stylesheets($context, array $blocks = array())
    {
        // line 89
        echo "    <!-- DataTables CSS -->
    ";
        // line 90
        if (isset($context['assetic']['debug']) && $context['assetic']['debug']) {
            // asset "2c3b0f2_0"
            $context["asset_url"] = isset($context['assetic']['use_controller']) && $context['assetic']['use_controller'] ? $this->env->getExtension('routing')->getPath("_assetic_2c3b0f2_0") : $this->env->getExtension('assets')->getAssetUrl("_controller/css/2c3b0f2_dataTables.bootstrap_1.css");
            // line 91
            echo "        <link rel=\"stylesheet\" href=\"";
            echo twig_escape_filter($this->env, (isset($context["asset_url"]) ? $context["asset_url"] : $this->getContext($context, "asset_url")), "html", null, true);
            echo "\" />
    ";
        } else {
            // asset "2c3b0f2"
            $context["asset_url"] = isset($context['assetic']['use_controller']) && $context['assetic']['use_controller'] ? $this->env->getExtension('routing')->getPath("_assetic_2c3b0f2") : $this->env->getExtension('assets')->getAssetUrl("_controller/css/2c3b0f2.css");
            echo "        <link rel=\"stylesheet\" href=\"";
            echo twig_escape_filter($this->env, (isset($context["asset_url"]) ? $context["asset_url"] : $this->getContext($context, "asset_url")), "html", null, true);
            echo "\" />
    ";
        }
        unset($context["asset_url"]);
    }

    // line 95
    public function block_javascripts($context, array $blocks = array())
    {
        // line 96
        echo "    <!-- DataTables JavaScript -->
    ";
        // line 97
        if (isset($context['assetic']['debug']) && $context['assetic']['debug']) {
            // asset "869cab4_0"
            $context["asset_url"] = isset($context['assetic']['use_controller']) && $context['assetic']['use_controller'] ? $this->env->getExtension('routing')->getPath("_assetic_869cab4_0") : $this->env->getExtension('assets')->getAssetUrl("_controller/js/869cab4_jquery.dataTables_1.js");
            // line 101
            echo "        <script type=\"text/javascript\" src=\"";
            echo twig_escape_filter($this->env, (isset($context["asset_url"]) ? $context["asset_url"] : $this->getContext($context, "asset_url")), "html", null, true);
            echo "\"></script>
    ";
            // asset "869cab4_1"
            $context["asset_url"] = isset($context['assetic']['use_controller']) && $context['assetic']['use_controller'] ? $this->env->getExtension('routing')->getPath("_assetic_869cab4_1") : $this->env->getExtension('assets')->getAssetUrl("_controller/js/869cab4_dataTables.bootstrap_2.js");
            echo "        <script type=\"text/javascript\" src=\"";
            echo twig_escape_filter($this->env, (isset($context["asset_url"]) ? $context["asset_url"] : $this->getContext($context, "asset_url")), "html", null, true);
            echo "\"></script>
    ";
        } else {
            // asset "869cab4"
            $context["asset_url"] = isset($context['assetic']['use_controller']) && $context['assetic']['use_controller'] ? $this->env->getExtension('routing')->getPath("_assetic_869cab4") : $this->env->getExtension('assets')->getAssetUrl("_controller/js/869cab4.js");
            echo "        <script type=\"text/javascript\" src=\"";
            echo twig_escape_filter($this->env, (isset($context["asset_url"]) ? $context["asset_url"] : $this->getContext($context, "asset_url")), "html", null, true);
            echo "\"></script>
    ";
        }
        unset($context["asset_url"]);
        // line 103
        echo "
    <script type=\"text/javascript\">
        \$('.datatable').dataTable();
    
        function eliminar(url){
            \$('#eliminarModal .modal-dialog .modal-content .modal-footer a.btn-danger').attr(\"href\", url)
            \$('#eliminarModal').modal()
        }
    </script>
    
";
    }

    public function getTemplateName()
    {
        return "AdminBundle:Tarifas:index.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  208 => 103,  188 => 101,  184 => 97,  181 => 96,  178 => 95,  162 => 91,  158 => 90,  155 => 89,  152 => 88,  118 => 56,  109 => 52,  100 => 48,  96 => 47,  90 => 44,  86 => 43,  82 => 42,  79 => 41,  74 => 40,  55 => 24,  33 => 4,  30 => 3,);
    }
}
