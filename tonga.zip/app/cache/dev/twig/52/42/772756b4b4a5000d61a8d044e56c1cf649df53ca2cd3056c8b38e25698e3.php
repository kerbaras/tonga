<?php

/* AdminBundle:Home:index.html.twig */
class __TwigTemplate_5242772756b4b4a5000d61a8d044e56c1cf649df53ca2cd3056c8b38e25698e3 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = $this->env->loadTemplate("AdminBundle::layout.html.twig");

        $this->blocks = array(
            'pageContainer' => array($this, 'block_pageContainer'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "AdminBundle::layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 3
    public function block_pageContainer($context, array $blocks = array())
    {
        // line 4
        echo "\t\t\t\t<!-- Page Heading -->
                <div class=\"row\">
                    <div class=\"col-lg-12\">
                        <h1 class=\"page-header\">
                            <i class=\"fa fa-dashboard\"></i>  Panel Principal
                        </h1>
                        <ol class=\"breadcrumb\">
                            <li class=\"active\">
                                <i class=\"fa fa-dashboard\"></i> Dashboard
                            </li>
                        </ol>

                        <div class=\"row\">
                            <div class=\"col-lg-3 col-md-6\">
                                <div class=\"panel panel-primary\">
                                    <div class=\"panel-heading\">
                                        <div class=\"row\">
                                            <div class=\"col-xs-3\">
                                                <i class=\"fa fa-group fa-5x\"></i>
                                            </div>
                                            <div class=\"col-xs-9 text-right\">
                                                <div class=\"huge\">26</div>
                                                <div>Clientes!</div>
                                            </div>
                                        </div>
                                    </div>
                                    <a href=\"";
        // line 30
        echo $this->env->getExtension('routing')->getPath("admin_clientes_homepage");
        echo "\">
                                        <div class=\"panel-footer\">
                                            <span class=\"pull-left\">Ver Listados</span>
                                            <span class=\"pull-right\"><i class=\"fa fa-arrow-circle-right\"></i></span>
                                            <div class=\"clearfix\"></div>
                                        </div>
                                    </a>
                                </div>
                            </div>
                            <div class=\"col-lg-3 col-md-6\">
                                <div class=\"panel panel-green\">
                                    <div class=\"panel-heading\">
                                        <div class=\"row\">
                                            <div class=\"col-xs-3\">
                                                <i class=\"fa fa-money fa-5x\"></i>
                                            </div>
                                            <div class=\"col-xs-9 text-right\">
                                                <div class=\"huge\">\$52.000</div>
                                                <div>Recaudados en el Mes!</div>
                                            </div>
                                        </div>
                                    </div>
                                    <a href=\"#\">
                                        <div class=\"panel-footer\">
                                            <span class=\"pull-left\">Ver Facturas</span>
                                            <span class=\"pull-right\"><i class=\"fa fa-arrow-circle-right\"></i></span>
                                            <div class=\"clearfix\"></div>
                                        </div>
                                    </a>
                                </div>
                            </div>
                            <div class=\"col-lg-3 col-md-6\">
                                <div class=\"panel panel-yellow\">
                                    <div class=\"panel-heading\">
                                        <div class=\"row\">
                                            <div class=\"col-xs-3\">
                                                <i class=\"fa fa-clock-o fa-5x\"></i>
                                            </div>
                                            <div class=\"col-xs-9 text-right\">
                                                <div class=\"huge\">14:32</div>
                                                <div>Caja Abierta!</div>
                                            </div>
                                        </div>
                                    </div>
                                    <a href=\"#\">
                                        <div class=\"panel-footer\">
                                            <span class=\"pull-left\">Ver Detalles</span>
                                            <span class=\"pull-right\"><i class=\"fa fa-arrow-circle-right\"></i></span>
                                            <div class=\"clearfix\"></div>
                                        </div>
                                    </a>
                                </div>
                            </div>
                            <div class=\"col-lg-3 col-md-6\">
                                <div class=\"panel panel-red\">
                                    <div class=\"panel-heading\">
                                        <div class=\"row\">
                                            <div class=\"col-xs-3\">
                                                <i class=\"fa fa-warning fa-5x\"></i>
                                            </div>
                                            <div class=\"col-xs-9 text-right\">
                                                <div class=\"huge\">13</div>
                                                <div>Adeudan el Mes!</div>
                                            </div>
                                        </div>
                                    </div>
                                    <a href=\"#\">
                                        <div class=\"panel-footer\">
                                            <span class=\"pull-left\">View Details</span>
                                            <span class=\"pull-right\"><i class=\"fa fa-arrow-circle-right\"></i></span>
                                            <div class=\"clearfix\"></div>
                                        </div>
                                    </a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- /.row -->
";
    }

    public function getTemplateName()
    {
        return "AdminBundle:Home:index.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  59 => 30,  31 => 4,  28 => 3,);
    }
}
