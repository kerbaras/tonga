<?php

use Symfony\Component\Routing\Exception\MethodNotAllowedException;
use Symfony\Component\Routing\Exception\ResourceNotFoundException;
use Symfony\Component\Routing\RequestContext;

/**
 * appDevUrlMatcher
 *
 * This class has been auto-generated
 * by the Symfony Routing Component.
 */
class appDevUrlMatcher extends Symfony\Bundle\FrameworkBundle\Routing\RedirectableUrlMatcher
{
    /**
     * Constructor.
     */
    public function __construct(RequestContext $context)
    {
        $this->context = $context;
    }

    public function match($pathinfo)
    {
        $allow = array();
        $pathinfo = rawurldecode($pathinfo);
        $context = $this->context;
        $request = $this->request;

        if (0 === strpos($pathinfo, '/css/2c3b0f2')) {
            // _assetic_2c3b0f2
            if ($pathinfo === '/css/2c3b0f2.css') {
                return array (  '_controller' => 'assetic.controller:render',  'name' => '2c3b0f2',  'pos' => NULL,  '_format' => 'css',  '_route' => '_assetic_2c3b0f2',);
            }

            // _assetic_2c3b0f2_0
            if ($pathinfo === '/css/2c3b0f2_dataTables.bootstrap_1.css') {
                return array (  '_controller' => 'assetic.controller:render',  'name' => '2c3b0f2',  'pos' => 0,  '_format' => 'css',  '_route' => '_assetic_2c3b0f2_0',);
            }

        }

        if (0 === strpos($pathinfo, '/js/869cab4')) {
            // _assetic_869cab4
            if ($pathinfo === '/js/869cab4.js') {
                return array (  '_controller' => 'assetic.controller:render',  'name' => '869cab4',  'pos' => NULL,  '_format' => 'js',  '_route' => '_assetic_869cab4',);
            }

            if (0 === strpos($pathinfo, '/js/869cab4_')) {
                // _assetic_869cab4_0
                if ($pathinfo === '/js/869cab4_jquery.dataTables_1.js') {
                    return array (  '_controller' => 'assetic.controller:render',  'name' => '869cab4',  'pos' => 0,  '_format' => 'js',  '_route' => '_assetic_869cab4_0',);
                }

                // _assetic_869cab4_1
                if ($pathinfo === '/js/869cab4_dataTables.bootstrap_2.js') {
                    return array (  '_controller' => 'assetic.controller:render',  'name' => '869cab4',  'pos' => 1,  '_format' => 'js',  '_route' => '_assetic_869cab4_1',);
                }

            }

        }

        if (0 === strpos($pathinfo, '/css')) {
            if (0 === strpos($pathinfo, '/css/e864e66')) {
                // _assetic_e864e66
                if ($pathinfo === '/css/e864e66.css') {
                    return array (  '_controller' => 'assetic.controller:render',  'name' => 'e864e66',  'pos' => NULL,  '_format' => 'css',  '_route' => '_assetic_e864e66',);
                }

                if (0 === strpos($pathinfo, '/css/e864e66_')) {
                    // _assetic_e864e66_0
                    if ($pathinfo === '/css/e864e66_bootstrap.min_1.css') {
                        return array (  '_controller' => 'assetic.controller:render',  'name' => 'e864e66',  'pos' => 0,  '_format' => 'css',  '_route' => '_assetic_e864e66_0',);
                    }

                    // _assetic_e864e66_1
                    if ($pathinfo === '/css/e864e66_metisMenu.min_2.css') {
                        return array (  '_controller' => 'assetic.controller:render',  'name' => 'e864e66',  'pos' => 1,  '_format' => 'css',  '_route' => '_assetic_e864e66_1',);
                    }

                    // _assetic_e864e66_2
                    if ($pathinfo === '/css/e864e66_jquery-ui_3.css') {
                        return array (  '_controller' => 'assetic.controller:render',  'name' => 'e864e66',  'pos' => 2,  '_format' => 'css',  '_route' => '_assetic_e864e66_2',);
                    }

                }

            }

            if (0 === strpos($pathinfo, '/css/7713a1e')) {
                // _assetic_7713a1e
                if ($pathinfo === '/css/7713a1e.css') {
                    return array (  '_controller' => 'assetic.controller:render',  'name' => '7713a1e',  'pos' => NULL,  '_format' => 'css',  '_route' => '_assetic_7713a1e',);
                }

                // _assetic_7713a1e_0
                if ($pathinfo === '/css/7713a1e_sb-admin-2_1.css') {
                    return array (  '_controller' => 'assetic.controller:render',  'name' => '7713a1e',  'pos' => 0,  '_format' => 'css',  '_route' => '_assetic_7713a1e_0',);
                }

            }

            if (0 === strpos($pathinfo, '/css/ce93b7d')) {
                // _assetic_ce93b7d
                if ($pathinfo === '/css/ce93b7d.css') {
                    return array (  '_controller' => 'assetic.controller:render',  'name' => 'ce93b7d',  'pos' => NULL,  '_format' => 'css',  '_route' => '_assetic_ce93b7d',);
                }

                // _assetic_ce93b7d_0
                if ($pathinfo === '/css/ce93b7d_font-awesome.min_1.css') {
                    return array (  '_controller' => 'assetic.controller:render',  'name' => 'ce93b7d',  'pos' => 0,  '_format' => 'css',  '_route' => '_assetic_ce93b7d_0',);
                }

            }

        }

        if (0 === strpos($pathinfo, '/js/d679b17')) {
            // _assetic_d679b17
            if ($pathinfo === '/js/d679b17.js') {
                return array (  '_controller' => 'assetic.controller:render',  'name' => 'd679b17',  'pos' => NULL,  '_format' => 'js',  '_route' => '_assetic_d679b17',);
            }

            if (0 === strpos($pathinfo, '/js/d679b17_')) {
                if (0 === strpos($pathinfo, '/js/d679b17_jquery-')) {
                    // _assetic_d679b17_0
                    if ($pathinfo === '/js/d679b17_jquery-1.11.0_1.js') {
                        return array (  '_controller' => 'assetic.controller:render',  'name' => 'd679b17',  'pos' => 0,  '_format' => 'js',  '_route' => '_assetic_d679b17_0',);
                    }

                    // _assetic_d679b17_1
                    if ($pathinfo === '/js/d679b17_jquery-ui.min_2.js') {
                        return array (  '_controller' => 'assetic.controller:render',  'name' => 'd679b17',  'pos' => 1,  '_format' => 'js',  '_route' => '_assetic_d679b17_1',);
                    }

                }

                // _assetic_d679b17_2
                if ($pathinfo === '/js/d679b17_bootstrap.min_3.js') {
                    return array (  '_controller' => 'assetic.controller:render',  'name' => 'd679b17',  'pos' => 2,  '_format' => 'js',  '_route' => '_assetic_d679b17_2',);
                }

                // _assetic_d679b17_3
                if ($pathinfo === '/js/d679b17_metisMenu.min_4.js') {
                    return array (  '_controller' => 'assetic.controller:render',  'name' => 'd679b17',  'pos' => 3,  '_format' => 'js',  '_route' => '_assetic_d679b17_3',);
                }

                // _assetic_d679b17_4
                if ($pathinfo === '/js/d679b17_sb-admin-2_5.js') {
                    return array (  '_controller' => 'assetic.controller:render',  'name' => 'd679b17',  'pos' => 4,  '_format' => 'js',  '_route' => '_assetic_d679b17_4',);
                }

            }

        }

        if (0 === strpos($pathinfo, '/_')) {
            // _wdt
            if (0 === strpos($pathinfo, '/_wdt') && preg_match('#^/_wdt/(?P<token>[^/]++)$#s', $pathinfo, $matches)) {
                return $this->mergeDefaults(array_replace($matches, array('_route' => '_wdt')), array (  '_controller' => 'web_profiler.controller.profiler:toolbarAction',));
            }

            if (0 === strpos($pathinfo, '/_profiler')) {
                // _profiler_home
                if (rtrim($pathinfo, '/') === '/_profiler') {
                    if (substr($pathinfo, -1) !== '/') {
                        return $this->redirect($pathinfo.'/', '_profiler_home');
                    }

                    return array (  '_controller' => 'web_profiler.controller.profiler:homeAction',  '_route' => '_profiler_home',);
                }

                if (0 === strpos($pathinfo, '/_profiler/search')) {
                    // _profiler_search
                    if ($pathinfo === '/_profiler/search') {
                        return array (  '_controller' => 'web_profiler.controller.profiler:searchAction',  '_route' => '_profiler_search',);
                    }

                    // _profiler_search_bar
                    if ($pathinfo === '/_profiler/search_bar') {
                        return array (  '_controller' => 'web_profiler.controller.profiler:searchBarAction',  '_route' => '_profiler_search_bar',);
                    }

                }

                // _profiler_purge
                if ($pathinfo === '/_profiler/purge') {
                    return array (  '_controller' => 'web_profiler.controller.profiler:purgeAction',  '_route' => '_profiler_purge',);
                }

                // _profiler_info
                if (0 === strpos($pathinfo, '/_profiler/info') && preg_match('#^/_profiler/info/(?P<about>[^/]++)$#s', $pathinfo, $matches)) {
                    return $this->mergeDefaults(array_replace($matches, array('_route' => '_profiler_info')), array (  '_controller' => 'web_profiler.controller.profiler:infoAction',));
                }

                // _profiler_phpinfo
                if ($pathinfo === '/_profiler/phpinfo') {
                    return array (  '_controller' => 'web_profiler.controller.profiler:phpinfoAction',  '_route' => '_profiler_phpinfo',);
                }

                // _profiler_search_results
                if (preg_match('#^/_profiler/(?P<token>[^/]++)/search/results$#s', $pathinfo, $matches)) {
                    return $this->mergeDefaults(array_replace($matches, array('_route' => '_profiler_search_results')), array (  '_controller' => 'web_profiler.controller.profiler:searchResultsAction',));
                }

                // _profiler
                if (preg_match('#^/_profiler/(?P<token>[^/]++)$#s', $pathinfo, $matches)) {
                    return $this->mergeDefaults(array_replace($matches, array('_route' => '_profiler')), array (  '_controller' => 'web_profiler.controller.profiler:panelAction',));
                }

                // _profiler_router
                if (preg_match('#^/_profiler/(?P<token>[^/]++)/router$#s', $pathinfo, $matches)) {
                    return $this->mergeDefaults(array_replace($matches, array('_route' => '_profiler_router')), array (  '_controller' => 'web_profiler.controller.router:panelAction',));
                }

                // _profiler_exception
                if (preg_match('#^/_profiler/(?P<token>[^/]++)/exception$#s', $pathinfo, $matches)) {
                    return $this->mergeDefaults(array_replace($matches, array('_route' => '_profiler_exception')), array (  '_controller' => 'web_profiler.controller.exception:showAction',));
                }

                // _profiler_exception_css
                if (preg_match('#^/_profiler/(?P<token>[^/]++)/exception\\.css$#s', $pathinfo, $matches)) {
                    return $this->mergeDefaults(array_replace($matches, array('_route' => '_profiler_exception_css')), array (  '_controller' => 'web_profiler.controller.exception:cssAction',));
                }

            }

            if (0 === strpos($pathinfo, '/_configurator')) {
                // _configurator_home
                if (rtrim($pathinfo, '/') === '/_configurator') {
                    if (substr($pathinfo, -1) !== '/') {
                        return $this->redirect($pathinfo.'/', '_configurator_home');
                    }

                    return array (  '_controller' => 'Sensio\\Bundle\\DistributionBundle\\Controller\\ConfiguratorController::checkAction',  '_route' => '_configurator_home',);
                }

                // _configurator_step
                if (0 === strpos($pathinfo, '/_configurator/step') && preg_match('#^/_configurator/step/(?P<index>[^/]++)$#s', $pathinfo, $matches)) {
                    return $this->mergeDefaults(array_replace($matches, array('_route' => '_configurator_step')), array (  '_controller' => 'Sensio\\Bundle\\DistributionBundle\\Controller\\ConfiguratorController::stepAction',));
                }

                // _configurator_final
                if ($pathinfo === '/_configurator/final') {
                    return array (  '_controller' => 'Sensio\\Bundle\\DistributionBundle\\Controller\\ConfiguratorController::finalAction',  '_route' => '_configurator_final',);
                }

            }

        }

        // admin_homepage
        if (rtrim($pathinfo, '/') === '') {
            if (substr($pathinfo, -1) !== '/') {
                return $this->redirect($pathinfo.'/', 'admin_homepage');
            }

            return array (  '_controller' => 'MPM\\Bundle\\AdminBundle\\Controller\\HomeController::indexAction',  '_route' => 'admin_homepage',);
        }

        if (0 === strpos($pathinfo, '/log')) {
            if (0 === strpos($pathinfo, '/login')) {
                // login
                if ($pathinfo === '/login') {
                    return array (  '_controller' => 'MPM\\Bundle\\AdminBundle\\Controller\\HomeController::loginAction',  '_route' => 'login',);
                }

                // login_check
                if ($pathinfo === '/login/check') {
                    return array('_route' => 'login_check');
                }

            }

            // logout
            if ($pathinfo === '/logout') {
                return array('_route' => 'logout');
            }

        }

        if (0 === strpos($pathinfo, '/clientes')) {
            // admin_clientes_homepage
            if (rtrim($pathinfo, '/') === '/clientes') {
                if (substr($pathinfo, -1) !== '/') {
                    return $this->redirect($pathinfo.'/', 'admin_clientes_homepage');
                }

                return array (  '_controller' => 'MPM\\Bundle\\AdminBundle\\Controller\\ClientesController::indexAction',  '_route' => 'admin_clientes_homepage',);
            }

            // admin_clientes_show
            if (preg_match('#^/clientes/(?P<id>[^/]++)$#s', $pathinfo, $matches)) {
                if (!in_array($this->context->getMethod(), array('GET', 'HEAD'))) {
                    $allow = array_merge($allow, array('GET', 'HEAD'));
                    goto not_admin_clientes_show;
                }

                return $this->mergeDefaults(array_replace($matches, array('_route' => 'admin_clientes_show')), array (  '_controller' => 'MPM\\Bundle\\AdminBundle\\Controller\\ClientesController::showAction',));
            }
            not_admin_clientes_show:

            if (0 === strpos($pathinfo, '/clientes/nuevo')) {
                // admin_clientes_newpage
                if ($pathinfo === '/clientes/nuevo') {
                    if (!in_array($this->context->getMethod(), array('GET', 'HEAD'))) {
                        $allow = array_merge($allow, array('GET', 'HEAD'));
                        goto not_admin_clientes_newpage;
                    }

                    return array (  '_controller' => 'MPM\\Bundle\\AdminBundle\\Controller\\ClientesController::newAction',  '_route' => 'admin_clientes_newpage',);
                }
                not_admin_clientes_newpage:

                // admin_clientes_create
                if ($pathinfo === '/clientes/nuevo') {
                    if ($this->context->getMethod() != 'POST') {
                        $allow[] = 'POST';
                        goto not_admin_clientes_create;
                    }

                    return array (  '_controller' => 'MPM\\Bundle\\AdminBundle\\Controller\\ClientesController::createAction',  '_route' => 'admin_clientes_create',);
                }
                not_admin_clientes_create:

            }

            // admin_clientes_editpage
            if (preg_match('#^/clientes/(?P<id>[^/]++)/editar$#s', $pathinfo, $matches)) {
                if (!in_array($this->context->getMethod(), array('GET', 'HEAD'))) {
                    $allow = array_merge($allow, array('GET', 'HEAD'));
                    goto not_admin_clientes_editpage;
                }

                return $this->mergeDefaults(array_replace($matches, array('_route' => 'admin_clientes_editpage')), array (  '_controller' => 'MPM\\Bundle\\AdminBundle\\Controller\\ClientesController::editAction',));
            }
            not_admin_clientes_editpage:

            // admin_clientes_update
            if (preg_match('#^/clientes/(?P<id>[^/]++)/editar$#s', $pathinfo, $matches)) {
                if ($this->context->getMethod() != 'POST') {
                    $allow[] = 'POST';
                    goto not_admin_clientes_update;
                }

                return $this->mergeDefaults(array_replace($matches, array('_route' => 'admin_clientes_update')), array (  '_controller' => 'MPM\\Bundle\\AdminBundle\\Controller\\ClientesController::updateAction',));
            }
            not_admin_clientes_update:

            // admin_clientes_photo
            if (preg_match('#^/clientes/(?P<id>[^/]++)/photo$#s', $pathinfo, $matches)) {
                if (!in_array($this->context->getMethod(), array('GET', 'HEAD'))) {
                    $allow = array_merge($allow, array('GET', 'HEAD'));
                    goto not_admin_clientes_photo;
                }

                return $this->mergeDefaults(array_replace($matches, array('_route' => 'admin_clientes_photo')), array (  '_controller' => 'MPM\\Bundle\\AdminBundle\\Controller\\ClientesController::showPhotoAction',));
            }
            not_admin_clientes_photo:

            // admin_clientes_delete
            if (preg_match('#^/clientes/(?P<id>[^/]++)/eliminar$#s', $pathinfo, $matches)) {
                if (!in_array($this->context->getMethod(), array('GET', 'HEAD'))) {
                    $allow = array_merge($allow, array('GET', 'HEAD'));
                    goto not_admin_clientes_delete;
                }

                return $this->mergeDefaults(array_replace($matches, array('_route' => 'admin_clientes_delete')), array (  '_controller' => 'MPM\\Bundle\\AdminBundle\\Controller\\ClientesController::removeAction',));
            }
            not_admin_clientes_delete:

        }

        if (0 === strpos($pathinfo, '/personal')) {
            // admin_personal_homepage
            if (rtrim($pathinfo, '/') === '/personal') {
                if (substr($pathinfo, -1) !== '/') {
                    return $this->redirect($pathinfo.'/', 'admin_personal_homepage');
                }

                return array (  '_controller' => 'MPM\\Bundle\\AdminBundle\\Controller\\PersonalController::indexAction',  '_route' => 'admin_personal_homepage',);
            }

            if (0 === strpos($pathinfo, '/personal/nuevo')) {
                // admin_personal_newpage
                if ($pathinfo === '/personal/nuevo') {
                    if (!in_array($this->context->getMethod(), array('GET', 'HEAD'))) {
                        $allow = array_merge($allow, array('GET', 'HEAD'));
                        goto not_admin_personal_newpage;
                    }

                    return array (  '_controller' => 'MPM\\Bundle\\AdminBundle\\Controller\\PersonalController::newAction',  '_route' => 'admin_personal_newpage',);
                }
                not_admin_personal_newpage:

                // admin_personal_create
                if ($pathinfo === '/personal/nuevo') {
                    if ($this->context->getMethod() != 'POST') {
                        $allow[] = 'POST';
                        goto not_admin_personal_create;
                    }

                    return array (  '_controller' => 'MPM\\Bundle\\AdminBundle\\Controller\\PersonalController::createAction',  '_route' => 'admin_personal_create',);
                }
                not_admin_personal_create:

            }

            // admin_personal_editpage
            if (preg_match('#^/personal/(?P<id>[^/]++)/editar$#s', $pathinfo, $matches)) {
                if (!in_array($this->context->getMethod(), array('GET', 'HEAD'))) {
                    $allow = array_merge($allow, array('GET', 'HEAD'));
                    goto not_admin_personal_editpage;
                }

                return $this->mergeDefaults(array_replace($matches, array('_route' => 'admin_personal_editpage')), array (  '_controller' => 'MPM\\Bundle\\AdminBundle\\Controller\\PersonalController::editAction',));
            }
            not_admin_personal_editpage:

            // admin_personal_update
            if (preg_match('#^/personal/(?P<id>[^/]++)/editar$#s', $pathinfo, $matches)) {
                if ($this->context->getMethod() != 'POST') {
                    $allow[] = 'POST';
                    goto not_admin_personal_update;
                }

                return $this->mergeDefaults(array_replace($matches, array('_route' => 'admin_personal_update')), array (  '_controller' => 'MPM\\Bundle\\AdminBundle\\Controller\\PersonalController::updateAction',));
            }
            not_admin_personal_update:

            // admin_personal_photo
            if (preg_match('#^/personal/(?P<id>[^/]++)/photo$#s', $pathinfo, $matches)) {
                if (!in_array($this->context->getMethod(), array('GET', 'HEAD'))) {
                    $allow = array_merge($allow, array('GET', 'HEAD'));
                    goto not_admin_personal_photo;
                }

                return $this->mergeDefaults(array_replace($matches, array('_route' => 'admin_personal_photo')), array (  '_controller' => 'MPM\\Bundle\\AdminBundle\\Controller\\PersonalController::showPhotoAction',));
            }
            not_admin_personal_photo:

            // admin_personal_delete
            if (preg_match('#^/personal/(?P<id>[^/]++)/eliminar$#s', $pathinfo, $matches)) {
                if (!in_array($this->context->getMethod(), array('GET', 'HEAD'))) {
                    $allow = array_merge($allow, array('GET', 'HEAD'));
                    goto not_admin_personal_delete;
                }

                return $this->mergeDefaults(array_replace($matches, array('_route' => 'admin_personal_delete')), array (  '_controller' => 'MPM\\Bundle\\AdminBundle\\Controller\\PersonalController::removeAction',));
            }
            not_admin_personal_delete:

        }

        if (0 === strpos($pathinfo, '/tarifas')) {
            // admin_tarifas_homepage
            if (rtrim($pathinfo, '/') === '/tarifas') {
                if (substr($pathinfo, -1) !== '/') {
                    return $this->redirect($pathinfo.'/', 'admin_tarifas_homepage');
                }

                return array (  '_controller' => 'MPM\\Bundle\\AdminBundle\\Controller\\TarifasController::indexAction',  '_route' => 'admin_tarifas_homepage',);
            }

            if (0 === strpos($pathinfo, '/tarifas/nueva')) {
                // admin_tarifas_newpage
                if ($pathinfo === '/tarifas/nueva') {
                    if (!in_array($this->context->getMethod(), array('GET', 'HEAD'))) {
                        $allow = array_merge($allow, array('GET', 'HEAD'));
                        goto not_admin_tarifas_newpage;
                    }

                    return array (  '_controller' => 'MPM\\Bundle\\AdminBundle\\Controller\\TarifasController::newAction',  '_route' => 'admin_tarifas_newpage',);
                }
                not_admin_tarifas_newpage:

                // admin_tarifas_create
                if ($pathinfo === '/tarifas/nueva') {
                    if ($this->context->getMethod() != 'POST') {
                        $allow[] = 'POST';
                        goto not_admin_tarifas_create;
                    }

                    return array (  '_controller' => 'MPM\\Bundle\\AdminBundle\\Controller\\TarifasController::createAction',  '_route' => 'admin_tarifas_create',);
                }
                not_admin_tarifas_create:

            }

            // admin_tarifas_editpage
            if (preg_match('#^/tarifas/(?P<id>[^/]++)/editar$#s', $pathinfo, $matches)) {
                if (!in_array($this->context->getMethod(), array('GET', 'HEAD'))) {
                    $allow = array_merge($allow, array('GET', 'HEAD'));
                    goto not_admin_tarifas_editpage;
                }

                return $this->mergeDefaults(array_replace($matches, array('_route' => 'admin_tarifas_editpage')), array (  '_controller' => 'MPM\\Bundle\\AdminBundle\\Controller\\TarifasController::editAction',));
            }
            not_admin_tarifas_editpage:

            // admin_tarifas_update
            if (preg_match('#^/tarifas/(?P<id>[^/]++)/editar$#s', $pathinfo, $matches)) {
                if ($this->context->getMethod() != 'POST') {
                    $allow[] = 'POST';
                    goto not_admin_tarifas_update;
                }

                return $this->mergeDefaults(array_replace($matches, array('_route' => 'admin_tarifas_update')), array (  '_controller' => 'MPM\\Bundle\\AdminBundle\\Controller\\TarifasController::updateAction',));
            }
            not_admin_tarifas_update:

            // admin_tarifas_delete
            if (preg_match('#^/tarifas/(?P<id>[^/]++)/eliminar$#s', $pathinfo, $matches)) {
                if (!in_array($this->context->getMethod(), array('GET', 'HEAD'))) {
                    $allow = array_merge($allow, array('GET', 'HEAD'));
                    goto not_admin_tarifas_delete;
                }

                return $this->mergeDefaults(array_replace($matches, array('_route' => 'admin_tarifas_delete')), array (  '_controller' => 'MPM\\Bundle\\AdminBundle\\Controller\\TarifasController::removeAction',));
            }
            not_admin_tarifas_delete:

        }

        throw 0 < count($allow) ? new MethodNotAllowedException(array_unique($allow)) : new ResourceNotFoundException();
    }
}
