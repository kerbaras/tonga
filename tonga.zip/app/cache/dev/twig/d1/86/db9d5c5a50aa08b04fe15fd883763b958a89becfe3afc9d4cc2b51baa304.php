<?php

/* AdminBundle:Clientes:show.html.twig */
class __TwigTemplate_d186db9d5c5a50aa08b04fe15fd883763b958a89becfe3afc9d4cc2b51baa304 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = $this->env->loadTemplate("AdminBundle::layout.html.twig");

        $this->blocks = array(
            'pageContainer' => array($this, 'block_pageContainer'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "AdminBundle::layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 3
    public function block_pageContainer($context, array $blocks = array())
    {
        // line 4
        echo "\t\t\t\t<!-- Page Heading -->
                <div class=\"row\">
                    <div class=\"col-lg-12\">
                        <h1 class=\"page-header\">
                            <i class=\"fa fa-group\"></i> Clientes <small>Gestor de clientes</small>
                        </h1>
                        <ol class=\"breadcrumb\">
                            <li>
                                <a href=\"";
        // line 12
        echo $this->env->getExtension('routing')->getPath("admin_clientes_homepage");
        echo "\"><i class=\"fa fa-group\"></i> Clientes</a>
                            </li>
                            <li class=\"active\">
                                ";
        // line 15
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["cliente"]) ? $context["cliente"] : $this->getContext($context, "cliente")), "apellido", array()), "html", null, true);
        echo ", ";
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["cliente"]) ? $context["cliente"] : $this->getContext($context, "cliente")), "nombre", array()), "html", null, true);
        echo "
                            </li>
                        </ol>

                        <div class=\"row\">
                            <div class=\"col-lg-12\">
                                <div class=\"row\">
                                    <div class=\"col-md-2\">
                                        <img src=\"";
        // line 23
        echo twig_escape_filter($this->env, $this->env->getExtension('routing')->getPath("admin_clientes_photo", array("id" => $this->getAttribute((isset($context["cliente"]) ? $context["cliente"] : $this->getContext($context, "cliente")), "id", array()))), "html", null, true);
        echo "\" style=\"width: 100%; max-width: 250px; align:center;\" />
                                    </div>
                                    <div class=\"col-md-10\">
                                        <div class=\"row\">
                                            <div class=\"col-md-12\"><strong>";
        // line 27
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["cliente"]) ? $context["cliente"] : $this->getContext($context, "cliente")), "apellido", array()), "html", null, true);
        echo ", ";
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["cliente"]) ? $context["cliente"] : $this->getContext($context, "cliente")), "nombre", array()), "html", null, true);
        echo "</strong><br /></div>

                                            <div class=\"col-md-2\"><strong>DNI</strong></div>
                                            <div class=\"col-md-10\"><em>";
        // line 30
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["cliente"]) ? $context["cliente"] : $this->getContext($context, "cliente")), "dni", array()), "html", null, true);
        echo "</em><br /></div>

                                            <div class=\"col-md-2\"><strong>E-Mail</strong></div>
                                            <div class=\"col-md-10\"><em>";
        // line 33
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["cliente"]) ? $context["cliente"] : $this->getContext($context, "cliente")), "mail", array()), "html", null, true);
        echo "</em><br /></div>

                                            <div class=\"col-md-2\"><strong>Teléfono</strong></div>
                                            <div class=\"col-md-10\"><em>";
        // line 36
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["cliente"]) ? $context["cliente"] : $this->getContext($context, "cliente")), "telefono", array()), "html", null, true);
        echo "</em><br /></div>


                                            <div class=\"col-md-2\"><strong>Cuóta</strong></div>
                                            <div class=\"col-md-10\"><em>";
        // line 40
        echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute((isset($context["cliente"]) ? $context["cliente"] : $this->getContext($context, "cliente")), "tarifa", array()), "nombre", array()), "html", null, true);
        echo " (\$";
        echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute((isset($context["cliente"]) ? $context["cliente"] : $this->getContext($context, "cliente")), "tarifa", array()), "monto", array()), "html", null, true);
        echo ")</em></div>

                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- /.row -->
";
    }

    public function getTemplateName()
    {
        return "AdminBundle:Clientes:show.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  94 => 40,  87 => 36,  81 => 33,  75 => 30,  67 => 27,  60 => 23,  47 => 15,  41 => 12,  31 => 4,  28 => 3,);
    }
}
