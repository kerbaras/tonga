<?php

/* AdminBundle:Personal:index.html.twig */
class __TwigTemplate_de630d324f8183e7085845806e052c3a6bae838886e171eb85cad9304a26d974 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = $this->env->loadTemplate("AdminBundle::layout.html.twig");

        $this->blocks = array(
            'pageContainer' => array($this, 'block_pageContainer'),
            'stylesheets' => array($this, 'block_stylesheets'),
            'javascripts' => array($this, 'block_javascripts'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "AdminBundle::layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 3
    public function block_pageContainer($context, array $blocks = array())
    {
        // line 4
        echo "\t\t\t\t<!-- Page Heading -->
                <div class=\"row\">
                    <div class=\"col-lg-12\">
                        <h1 class=\"page-header\">
                            <i class=\"fa fa-group\"></i>  Personal <small>Gestor del Personal</small>
                        </h1>
                        <ol class=\"breadcrumb\">
                            <li class=\"active\">
                                <i class=\"fa fa-briefcase\"></i> Personal
                            </li>
                        </ol>

                        <div class=\"row\">
                            <div class=\"col-lg-12\">
                                <div class=\"panel panel-default\">
                                    <div class=\"panel-heading\">
                                        Personal

                                        <div class=\"pull-right\">
                                            <div class=\"btn-group\">
                                                <a href=\"";
        // line 24
        echo $this->env->getExtension('routing')->getPath("admin_personal_newpage");
        echo "\" class=\"btn btn-default btn-xs\"><i class=\"fa fa-plus\"></i> Agregar Personal</a>
                                            </div>
                                        </div>
                                    </div><!-- / .panel-heading -->
                                    <div class=\"panel-body\">
                                        <div class=\"table-responsive\">
                                            <table id=\"tableClientes\" class=\"table table-striped table-bordered table-hover datatable\">
                                                <thead>
                                                    <tr>
                                                        <th>Apellido</th>
                                                        <th>Nombre</th>
                                                        <th>DNI</th>
                                                        <th>Telefono</th>
                                                        <th>Tipo</th>
                                                        <th>Acciones</th>
                                                    </tr>
                                                </thead>
                                                <tbody>
                                                ";
        // line 42
        $context['_parent'] = (array) $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["personales"]) ? $context["personales"] : $this->getContext($context, "personales")));
        $context['_iterated'] = false;
        foreach ($context['_seq'] as $context["_key"] => $context["personal"]) {
            // line 43
            echo "                                                    <tr valign=\"middle\">
                                                        <td>";
            // line 44
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["personal"]) ? $context["personal"] : $this->getContext($context, "personal")), "apellido", array()), "html", null, true);
            echo "</td>
                                                        <td>";
            // line 45
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["personal"]) ? $context["personal"] : $this->getContext($context, "personal")), "nombre", array()), "html", null, true);
            echo "</td>
                                                        <td>";
            // line 46
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["personal"]) ? $context["personal"] : $this->getContext($context, "personal")), "dni", array()), "html", null, true);
            echo "</td>
                                                        <td>";
            // line 47
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["personal"]) ? $context["personal"] : $this->getContext($context, "personal")), "telefono", array()), "html", null, true);
            echo "</td>
                                                        <td>";
            // line 48
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["personal"]) ? $context["personal"] : $this->getContext($context, "personal")), "tipo", array()), "html", null, true);
            echo "</td>
                                                        <td align=\"center\">
                                                            <a href=\"#\" class=\"btn btn-info btn-circle\"><i class=\"fa fa-search\"></i></a>
                                                            <a href=\"";
            // line 51
            echo twig_escape_filter($this->env, $this->env->getExtension('routing')->getPath("admin_personal_editpage", array("id" => $this->getAttribute((isset($context["personal"]) ? $context["personal"] : $this->getContext($context, "personal")), "id", array()))), "html", null, true);
            echo "\" class=\"btn btn-warning btn-circle\"><i class=\"fa fa-edit\"></i></a>
                                                            <a href=\"javascript:eliminar('";
            // line 52
            echo twig_escape_filter($this->env, $this->env->getExtension('routing')->getPath("admin_personal_delete", array("id" => $this->getAttribute((isset($context["personal"]) ? $context["personal"] : $this->getContext($context, "personal")), "id", array()))), "html", null, true);
            echo "');\" class=\"btn btn-danger btn-circle\"><i class=\"fa fa-trash\"></i></a>
                                                        </td>
                                                    </tr>
                                                ";
            $context['_iterated'] = true;
        }
        if (!$context['_iterated']) {
            // line 56
            echo "                                                    <tr class=\"warning\">
                                                        <td colspan=\"6\"><strong>No se encontraron miembros del Personal</strong></td>
                                                    </tr>
                                                ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['personal'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 60
        echo "                                                </tbody>
                                            </table>
                                        </div>
                                    </div><!-- / .panel-body -->
                                </div><!-- / .panel -->
                            </div>
                        </div>
                    </div>
                </div>
                <!-- /.row -->
                
                <!-- Modal Eliminar -->
                <div class=\"modal fade\" id=\"eliminarModal\" tabindex=\"-1\" role=\"dialog\" aria-labelledby=\"eliminarModalLabel\" aria-hidden=\"true\">
                  <div class=\"modal-dialog\">
                    <div class=\"modal-content\">
                      <div class=\"modal-header\">
                        <button type=\"button\" class=\"close\" data-dismiss=\"modal\"><span aria-hidden=\"true\">&times;</span><span class=\"sr-only\">Cerrar</span></button>
                        <h4 class=\"modal-title\" id=\"eliminarModalLabel\">Eliminar Personal</h4>
                      </div>
                      <div class=\"modal-body\">
                        <p>¿Esta seguro que desea eliminar al personal?</p>
                      </div>
                      <div class=\"modal-footer\">
                        <button type=\"button\" class=\"btn btn-default\" data-dismiss=\"modal\">Cancelar</button>
                        <a href=\"\" class=\"btn btn-danger\">Eliminar</a>
                      </div>
                    </div><!-- /.modal-content -->
                  </div><!-- /.modal-dialog -->
                </div><!-- /.modal Eliminar -->

";
    }

    // line 92
    public function block_stylesheets($context, array $blocks = array())
    {
        // line 93
        echo "    <!-- DataTables CSS -->
    ";
        // line 94
        if (isset($context['assetic']['debug']) && $context['assetic']['debug']) {
            // asset "2c3b0f2_0"
            $context["asset_url"] = isset($context['assetic']['use_controller']) && $context['assetic']['use_controller'] ? $this->env->getExtension('routing')->getPath("_assetic_2c3b0f2_0") : $this->env->getExtension('assets')->getAssetUrl("_controller/css/2c3b0f2_dataTables.bootstrap_1.css");
            // line 95
            echo "        <link rel=\"stylesheet\" href=\"";
            echo twig_escape_filter($this->env, (isset($context["asset_url"]) ? $context["asset_url"] : $this->getContext($context, "asset_url")), "html", null, true);
            echo "\" />
    ";
        } else {
            // asset "2c3b0f2"
            $context["asset_url"] = isset($context['assetic']['use_controller']) && $context['assetic']['use_controller'] ? $this->env->getExtension('routing')->getPath("_assetic_2c3b0f2") : $this->env->getExtension('assets')->getAssetUrl("_controller/css/2c3b0f2.css");
            echo "        <link rel=\"stylesheet\" href=\"";
            echo twig_escape_filter($this->env, (isset($context["asset_url"]) ? $context["asset_url"] : $this->getContext($context, "asset_url")), "html", null, true);
            echo "\" />
    ";
        }
        unset($context["asset_url"]);
    }

    // line 99
    public function block_javascripts($context, array $blocks = array())
    {
        // line 100
        echo "    <!-- DataTables JavaScript -->
    ";
        // line 101
        if (isset($context['assetic']['debug']) && $context['assetic']['debug']) {
            // asset "869cab4_0"
            $context["asset_url"] = isset($context['assetic']['use_controller']) && $context['assetic']['use_controller'] ? $this->env->getExtension('routing')->getPath("_assetic_869cab4_0") : $this->env->getExtension('assets')->getAssetUrl("_controller/js/869cab4_jquery.dataTables_1.js");
            // line 105
            echo "        <script type=\"text/javascript\" src=\"";
            echo twig_escape_filter($this->env, (isset($context["asset_url"]) ? $context["asset_url"] : $this->getContext($context, "asset_url")), "html", null, true);
            echo "\"></script>
    ";
            // asset "869cab4_1"
            $context["asset_url"] = isset($context['assetic']['use_controller']) && $context['assetic']['use_controller'] ? $this->env->getExtension('routing')->getPath("_assetic_869cab4_1") : $this->env->getExtension('assets')->getAssetUrl("_controller/js/869cab4_dataTables.bootstrap_2.js");
            echo "        <script type=\"text/javascript\" src=\"";
            echo twig_escape_filter($this->env, (isset($context["asset_url"]) ? $context["asset_url"] : $this->getContext($context, "asset_url")), "html", null, true);
            echo "\"></script>
    ";
        } else {
            // asset "869cab4"
            $context["asset_url"] = isset($context['assetic']['use_controller']) && $context['assetic']['use_controller'] ? $this->env->getExtension('routing')->getPath("_assetic_869cab4") : $this->env->getExtension('assets')->getAssetUrl("_controller/js/869cab4.js");
            echo "        <script type=\"text/javascript\" src=\"";
            echo twig_escape_filter($this->env, (isset($context["asset_url"]) ? $context["asset_url"] : $this->getContext($context, "asset_url")), "html", null, true);
            echo "\"></script>
    ";
        }
        unset($context["asset_url"]);
        // line 107
        echo "
    <script type=\"text/javascript\">
        \$('.datatable').dataTable();
    
        function eliminar(url){
            \$('#eliminarModal .modal-dialog .modal-content .modal-footer a.btn-danger').attr(\"href\", url)
            \$('#eliminarModal').modal()
        }
    </script>
    
";
    }

    public function getTemplateName()
    {
        return "AdminBundle:Personal:index.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  218 => 107,  198 => 105,  194 => 101,  191 => 100,  188 => 99,  172 => 95,  168 => 94,  165 => 93,  162 => 92,  128 => 60,  119 => 56,  110 => 52,  106 => 51,  100 => 48,  96 => 47,  92 => 46,  88 => 45,  84 => 44,  81 => 43,  76 => 42,  55 => 24,  33 => 4,  30 => 3,);
    }
}
