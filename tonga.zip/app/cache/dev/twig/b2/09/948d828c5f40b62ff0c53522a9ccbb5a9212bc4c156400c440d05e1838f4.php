<?php

/* AdminBundle:Personal:new.html.twig */
class __TwigTemplate_b209948d828c5f40b62ff0c53522a9ccbb5a9212bc4c156400c440d05e1838f4 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = $this->env->loadTemplate("AdminBundle::layout.html.twig");

        $this->blocks = array(
            'pageContainer' => array($this, 'block_pageContainer'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "AdminBundle::layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 1
        $context["forms"] = $this->env->loadTemplate("AdminBundle:Functions:forms.html.twig");
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 5
    public function block_pageContainer($context, array $blocks = array())
    {
        // line 6
        echo "\t\t\t\t<!-- Page Heading -->
                <div class=\"row\">
                    <div class=\"col-lg-12\">
                        <h1 class=\"page-header\">
                            <i class=\"fa fa-group\"></i> Personal <small>Gestor del Personal</small>
                        </h1>
                        <ol class=\"breadcrumb\">
                            <li>
                                <a href=\"";
        // line 14
        echo $this->env->getExtension('routing')->getPath("admin_personal_homepage");
        echo "\"><i class=\"fa fa-briefcase\"></i> Personal</a>
                            </li>
                            ";
        // line 16
        if (((isset($context["action"]) ? $context["action"] : $this->getContext($context, "action")) == "Agregar")) {
            // line 17
            echo "                            <li class=\"active\">
                                Nuevo
                            </li>
                            ";
        } else {
            // line 21
            echo "                            <li>
                                <a href=\"";
            // line 22
            echo $this->env->getExtension('routing')->getPath("admin_personal_homepage");
            echo "\">";
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["personal"]) ? $context["personal"] : $this->getContext($context, "personal")), "apellido", array()), "html", null, true);
            echo ", ";
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["personal"]) ? $context["personal"] : $this->getContext($context, "personal")), "nombre", array()), "html", null, true);
            echo "</a>
                            </li>
                            <li class=\"active\">
                                Editar
                            </li>
                            ";
        }
        // line 28
        echo "                        </ol>

                        <div class=\"row\">
                            <div class=\"col-lg-12\">
                                <div class=\"panel panel-default\">
                                    <div class=\"panel-heading\">
                                        ";
        // line 34
        echo twig_escape_filter($this->env, (isset($context["action"]) ? $context["action"] : $this->getContext($context, "action")), "html", null, true);
        echo " un personal
                                    </div><!-- / .panel-heading -->
                                    <div class=\"panel-body\">
                                        <form class=\"form-horizontal\" role=\"form\" enctype=\"multipart/form-data\" method=\"post\">

                                          ";
        // line 39
        echo $context["forms"]->getinput("nombre", "Nombre", $this->getAttribute((isset($context["personal"]) ? $context["personal"] : $this->getContext($context, "personal")), "nombre", array()));
        echo "

                                          ";
        // line 41
        echo $context["forms"]->getinput("apellido", "Apellido", $this->getAttribute((isset($context["personal"]) ? $context["personal"] : $this->getContext($context, "personal")), "apellido", array()));
        echo "

                                          ";
        // line 43
        echo $context["forms"]->getinput("dni", "DNI", $this->getAttribute((isset($context["personal"]) ? $context["personal"] : $this->getContext($context, "personal")), "dni", array()));
        echo "

                                          <div class=\"form-group\">
                                              <label for=\"sexo\" class=\"col-md-2 control-label\">Sexo</label>
                                              <div class=\"col-md-10\">
                                                  <select class=\"form-control\" name=\"sexo\">
                                                      <option value=\"fem\"";
        // line 49
        if (($this->getAttribute((isset($context["personal"]) ? $context["personal"] : $this->getContext($context, "personal")), "sexo", array()) == true)) {
            echo "selected";
        }
        echo ">Femenino</option>
                                                      <option value=\"masc\"";
        // line 50
        if (($this->getAttribute((isset($context["personal"]) ? $context["personal"] : $this->getContext($context, "personal")), "sexo", array()) == false)) {
            echo "selected";
        }
        echo ">Masculino</option>
                                                  </select>
                                              </div>
                                          </div>

                                          ";
        // line 55
        echo $context["forms"]->getinput("mail", "E-Mail", $this->getAttribute((isset($context["personal"]) ? $context["personal"] : $this->getContext($context, "personal")), "mail", array()), "email");
        echo "

                                          ";
        // line 57
        echo $context["forms"]->getinput("telefono", "Teléfono", $this->getAttribute((isset($context["personal"]) ? $context["personal"] : $this->getContext($context, "personal")), "telefono", array()));
        echo "

                                          ";
        // line 59
        echo $context["forms"]->getinput("username", "Nombre de Usuario", $this->getAttribute((isset($context["personal"]) ? $context["personal"] : $this->getContext($context, "personal")), "username", array()));
        echo "

                                          ";
        // line 61
        echo $context["forms"]->getinput("password", "Contraseña", "", "password");
        echo "

                                          ";
        // line 63
        echo $context["forms"]->getinput("tipo", "Tipo de Personal", $this->getAttribute((isset($context["personal"]) ? $context["personal"] : $this->getContext($context, "personal")), "tipo", array()));
        echo "

                                          <div class=\"form-group\">
                                              <label for=\"role\" class=\"col-md-2 control-label\">Rol</label>
                                              <div class=\"col-md-10\">
                                                  <select class=\"form-control\" name=\"role\">
                                                      <option value=\"ROLE_SEC\"";
        // line 69
        if (($this->getAttribute((isset($context["personal"]) ? $context["personal"] : $this->getContext($context, "personal")), "role", array()) == "ROLE_SEC")) {
            echo " selected";
        }
        echo ">Secretario</option>
                                                      <option value=\"ROLE_PROF\"";
        // line 70
        if (($this->getAttribute((isset($context["personal"]) ? $context["personal"] : $this->getContext($context, "personal")), "role", array()) == "ROLE_PROF")) {
            echo " selected";
        }
        echo ">Profesor</option>
                                                      <option value=\"ROLE_ADMIN\"";
        // line 71
        if (($this->getAttribute((isset($context["personal"]) ? $context["personal"] : $this->getContext($context, "personal")), "role", array()) == "ROLE_ADMIN")) {
            echo " selected";
        }
        echo ">Administrador</option>
                                                  </select>
                                              </div>
                                          </div>

                                          ";
        // line 76
        echo $context["forms"]->getinput("image", "Imagen", "", "file");
        echo "

                                          <div class=\"form-group\">
                                            <div class=\"col-sm-offset-2 col-sm-10\">
                                              <button type=\"submit\" class=\"btn btn-primary\">Guardar</button>
                                            </div>
                                          </div>
                                        </form>
                                    </div><!-- / .panel-body -->
                                </div><!-- / .panel -->
                            </div>
                        </div>
                    </div>
                </div>
                <!-- /.row -->
";
    }

    public function getTemplateName()
    {
        return "AdminBundle:Personal:new.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  174 => 76,  164 => 71,  158 => 70,  152 => 69,  143 => 63,  138 => 61,  133 => 59,  128 => 57,  123 => 55,  113 => 50,  107 => 49,  98 => 43,  93 => 41,  88 => 39,  80 => 34,  72 => 28,  59 => 22,  56 => 21,  50 => 17,  48 => 16,  43 => 14,  33 => 6,  30 => 5,  25 => 1,);
    }
}
