<?php

// AdminBundle::layout.html.twig
return array (
  '2c3b0f2' => 
  array (
    0 => 
    array (
      0 => 'bundles/admin/css/plugins/dataTables.bootstrap.css',
    ),
    1 => 
    array (
      0 => 'cssrewrite',
    ),
    2 => 
    array (
      'output' => '_controller/css/2c3b0f2.css',
      'name' => '2c3b0f2',
      'debug' => NULL,
      'combine' => NULL,
      'vars' => 
      array (
      ),
    ),
  ),
  '869cab4' => 
  array (
    0 => 
    array (
      0 => '@AdminBundle/Resources/public/js/plugins/dataTables/jquery.dataTables.js',
      1 => '@AdminBundle/Resources/public/js/plugins/dataTables/dataTables.bootstrap.js',
    ),
    1 => 
    array (
    ),
    2 => 
    array (
      'output' => '_controller/js/869cab4.js',
      'name' => '869cab4',
      'debug' => NULL,
      'combine' => NULL,
      'vars' => 
      array (
      ),
    ),
  ),
  'e864e66' => 
  array (
    0 => 
    array (
      0 => 'bundles/admin/css/bootstrap.min.css',
      1 => 'bundles/admin/css/plugins/metisMenu/metisMenu.min.css',
      2 => 'bundles/admin/css/jquery-ui/jquery-ui.css',
    ),
    1 => 
    array (
      0 => 'cssrewrite',
    ),
    2 => 
    array (
      'output' => '_controller/css/e864e66.css',
      'name' => 'e864e66',
      'debug' => NULL,
      'combine' => NULL,
      'vars' => 
      array (
      ),
    ),
  ),
  '7713a1e' => 
  array (
    0 => 
    array (
      0 => '@AdminBundle/Resources/public/less/sb-admin-2.less',
    ),
    1 => 
    array (
    ),
    2 => 
    array (
      'output' => '_controller/css/7713a1e.css',
      'name' => '7713a1e',
      'debug' => NULL,
      'combine' => NULL,
      'vars' => 
      array (
      ),
    ),
  ),
  'ce93b7d' => 
  array (
    0 => 
    array (
      0 => 'bundles/admin/css/font-awesome.min.css',
    ),
    1 => 
    array (
      0 => 'cssrewrite',
    ),
    2 => 
    array (
      'output' => '_controller/css/ce93b7d.css',
      'name' => 'ce93b7d',
      'debug' => NULL,
      'combine' => NULL,
      'vars' => 
      array (
      ),
    ),
  ),
  'd679b17' => 
  array (
    0 => 
    array (
      0 => '@AdminBundle/Resources/public/js/jquery-1.11.0.js',
      1 => '@AdminBundle/Resources/public/js/jquery-ui.min.js',
      2 => '@AdminBundle/Resources/public/js/bootstrap.min.js',
      3 => '@AdminBundle/Resources/public/js/plugins/metisMenu/metisMenu.min.js',
      4 => '@AdminBundle/Resources/public/js/sb-admin-2.js',
    ),
    1 => 
    array (
    ),
    2 => 
    array (
      'output' => '_controller/js/d679b17.js',
      'name' => 'd679b17',
      'debug' => NULL,
      'combine' => NULL,
      'vars' => 
      array (
      ),
    ),
  ),
);
