<?php

/* AdminBundle:Extras:navigation.html.twig */
class __TwigTemplate_87a75c621986bae111c4b51d6d7d943dc619662f0a283fcaaa7b12b0b3d98b05 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 1
        echo "        <nav class=\"navbar navbar-inverse navbar-fixed-top\" role=\"navigation\">
            <div class=\"navbar-header\">
                <button type=\"button\" class=\"navbar-toggle\" data-toggle=\"collapse\" data-target=\".navbar-collapse\">
                    <span class=\"sr-only\">Toggle navigation</span>
                    <span class=\"icon-bar\"></span>
                    <span class=\"icon-bar\"></span>
                    <span class=\"icon-bar\"></span>
                </button>
                <a class=\"navbar-brand\" href=\"";
        // line 9
        echo $this->env->getExtension('routing')->getPath("admin_homepage");
        echo "\">PAG - Admin Panel</a>
            </div>
            <!-- /.navbar-header -->

            <ul class=\"nav navbar-top-links navbar-right\">
                ";
        // line 203
        echo "                <!-- /.dropdown -->
                <li class=\"dropdown\">
                    <a class=\"dropdown-toggle\" data-toggle=\"dropdown\" href=\"#\">
                        <i class=\"fa fa-user fa-fw\"></i>  <i class=\"fa fa-caret-down\"></i>
                    </a>
                    <ul class=\"dropdown-menu dropdown-user\">
                        <li><a href=\"#\"><i class=\"fa fa-user fa-fw\"></i> Perfil</a>
                        </li>
                        <li><a href=\"#\"><i class=\"fa fa-gear fa-fw\"></i> Configuraciones</a>
                        </li>
                        <li class=\"divider\"></li>
                        <li><a href=\"";
        // line 214
        echo $this->env->getExtension('routing')->getPath("logout");
        echo "\"><i class=\"fa fa-sign-out fa-fw\"></i> Logout</a>
                        </li>
                    </ul>
                    <!-- /.dropdown-user -->
                </li>
                <!-- /.dropdown -->
            </ul>
            <!-- /.navbar-top-links -->

            <div class=\"navbar-inverse sidebar\" role=\"navigation\">
                <div class=\"sidebar-nav navbar-collapse\">
                    <ul class=\"nav\" id=\"side-menu\">
                        <li";
        // line 226
        if (((isset($context["mainMenu"]) ? $context["mainMenu"] : $this->getContext($context, "mainMenu")) == "dash")) {
            echo " class=\"active\"";
        }
        echo ">
                            <a href=\"";
        // line 227
        echo $this->env->getExtension('routing')->getPath("admin_homepage");
        echo "\"><i class=\"fa fa-dashboard fa-fw\"></i> Dashboard</a>
                        </li>
                        <li";
        // line 229
        if (((isset($context["mainMenu"]) ? $context["mainMenu"] : $this->getContext($context, "mainMenu")) == "clientes")) {
            echo " class=\"active\"";
        }
        echo ">
                            <a href=\"";
        // line 230
        echo $this->env->getExtension('routing')->getPath("admin_clientes_homepage");
        echo "\"><i class=\"fa fa-group fa-fw\"></i> Clientes</a>
                        </li>
                        <li";
        // line 232
        if (((isset($context["mainMenu"]) ? $context["mainMenu"] : $this->getContext($context, "mainMenu")) == "usuarios")) {
            echo " class=\"active\"";
        }
        echo ">
                            <a href=\"";
        // line 233
        echo $this->env->getExtension('routing')->getPath("admin_personal_homepage");
        echo "\"><i class=\"fa fa-briefcase fa-fw\"></i> Personal</a>
                        </li>
                        <li";
        // line 235
        if ((((isset($context["mainMenu"]) ? $context["mainMenu"] : $this->getContext($context, "mainMenu")) == "facturas") || ((isset($context["mainMenu"]) ? $context["mainMenu"] : $this->getContext($context, "mainMenu")) == "facturar"))) {
            echo " class=\"active\"";
        }
        echo ">
                            <a href=\"javascript:void();\"><i class=\"fa fa-calculator fa-fw\"></i> Facturación<span class=\"fa arrow\"></span></a>
                            <ul class=\"nav nav-second-level\">
                                <li";
        // line 238
        if (((isset($context["mainMenu"]) ? $context["mainMenu"] : $this->getContext($context, "mainMenu")) == "facturar")) {
            echo " class=\"active\"";
        }
        echo ">
                                    <a href=\"#\"><i class=\"fa fa-credit-card\"></i> Facturar</a>
                                </li>
                                <li";
        // line 241
        if (((isset($context["mainMenu"]) ? $context["mainMenu"] : $this->getContext($context, "mainMenu")) == "facturas")) {
            echo " class=\"active\"";
        }
        echo ">
                                    <a href=\"#\"><i class=\"fa fa-table\"></i> Facturas</a>
                                </li>
                            </ul>
                        </li>
                        <li";
        // line 246
        if (((isset($context["mainMenu"]) ? $context["mainMenu"] : $this->getContext($context, "mainMenu")) == "tarifas")) {
            echo " class=\"active\"";
        }
        echo ">
                            <a href=\"";
        // line 247
        echo $this->env->getExtension('routing')->getPath("admin_tarifas_homepage");
        echo "\"><i class=\"fa fa-bar-chart fa-fw\"></i> Tarifas</a>
                        </li>
                        <li";
        // line 249
        if (((isset($context["mainMenu"]) ? $context["mainMenu"] : $this->getContext($context, "mainMenu")) == "reglas")) {
            echo " class=\"active\"";
        }
        echo ">
                            <a href=\"";
        // line 250
        echo $this->env->getExtension('routing')->getPath("admin_homepage");
        echo "\"><i class=\"fa fa-line-chart fa-fw\"></i> Reglas</a>
                        </li>
                        <li";
        // line 252
        if (((isset($context["mainMenu"]) ? $context["mainMenu"] : $this->getContext($context, "mainMenu")) == "logueo")) {
            echo " class=\"active\"";
        }
        echo ">
                            <a href=\"";
        // line 253
        echo $this->env->getExtension('routing')->getPath("admin_homepage");
        echo "\"><i class=\"fa fa-shield fa-fw\"></i> Logs</a>
                        </li>
                        <li";
        // line 255
        if (((isset($context["mainMenu"]) ? $context["mainMenu"] : $this->getContext($context, "mainMenu")) == "caja")) {
            echo " class=\"active\"";
        }
        echo ">
                            <a href=\"";
        // line 256
        echo $this->env->getExtension('routing')->getPath("admin_homepage");
        echo "\"><i class=\"fa fa-money fa-fw\"></i> Caja</a>
                        </li>
                    </ul>
                </div>
                <!-- /.sidebar-collapse -->
            </div>
            <!-- /.navbar-static-side -->
        </nav>";
    }

    public function getTemplateName()
    {
        return "AdminBundle:Extras:navigation.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  163 => 256,  157 => 255,  152 => 253,  146 => 252,  141 => 250,  135 => 249,  130 => 247,  124 => 246,  114 => 241,  106 => 238,  98 => 235,  93 => 233,  87 => 232,  82 => 230,  76 => 229,  71 => 227,  65 => 226,  50 => 214,  37 => 203,  29 => 9,  19 => 1,);
    }
}
