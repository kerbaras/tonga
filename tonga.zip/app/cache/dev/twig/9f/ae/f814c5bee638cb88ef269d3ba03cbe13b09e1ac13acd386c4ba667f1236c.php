<?php

/* AdminBundle:Home:login.html.twig */
class __TwigTemplate_9faef814c5bee638cb88ef269d3ba03cbe13b09e1ac13acd386c4ba667f1236c extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = $this->env->loadTemplate("AdminBundle::layout.html.twig");

        $this->blocks = array(
            'htmlBody' => array($this, 'block_htmlBody'),
            'javascripts' => array($this, 'block_javascripts'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "AdminBundle::layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 3
    public function block_htmlBody($context, array $blocks = array())
    {
        // line 4
        echo "    <div class=\"container\">
        <div class=\"row\">
            <div class=\"col-md-4 col-md-offset-4\">
                <div class=\"login-panel panel panel-default\" style=\"display: none;\">
                    <div class=\"panel-heading\">
                        <h3 class=\"panel-title\">Sign In</h3>
                    </div>
                    <div class=\"panel-body\">
                        ";
        // line 12
        if ((isset($context["error"]) ? $context["error"] : $this->getContext($context, "error"))) {
            // line 13
            echo "                            <div class=\"alert alert-danger\" style=\"display: none;\"><strong>";
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["error"]) ? $context["error"] : $this->getContext($context, "error")), "message", array()), "html", null, true);
            echo "</strong></div>
                        ";
        }
        // line 15
        echo "                        <form role=\"form\" id=\"frmLogin\" action=\"";
        echo $this->env->getExtension('routing')->getPath("login_check");
        echo "\" method=\"POST\">
                            <fieldset>
                                <div class=\"form-group\">
                                    <input class=\"form-control\" placeholder=\"Nombre de Usuario\" name=\"_username\" type=\"text\" required autofocus value=\"";
        // line 18
        echo twig_escape_filter($this->env, (isset($context["last_username"]) ? $context["last_username"] : $this->getContext($context, "last_username")), "html", null, true);
        echo "\">
                                </div>
                                <div class=\"form-group\">
                                    <input class=\"form-control\" placeholder=\"Contraseña\" name=\"_password\" type=\"password\" required>
                                </div>
                                <div class=\"checkbox\">
                                    <label>
                                        <input name=\"_remember_me\" type=\"checkbox\" checked>Recordarme
                                    </label>
                                </div>
                                <!-- Change this to a button or input when using this as a form -->
                                <input type=\"submit\" class=\"btn btn-lg btn-success btn-block\" value=\"Login\" />
                            </fieldset>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
";
    }

    // line 39
    public function block_javascripts($context, array $blocks = array())
    {
        // line 40
        echo "    <script type=\"text/javascript\">
        \$( \".login-panel\" ).show('drop', {'direction': 'right'}, 1500, \$('.alert').fadeIn() );
        /*var seguir = false;
        \$('#frmLogin').submit(function (event) {
            \$( \".login-panel\" ).hide('drop');
            return;
        })*/
    </script>
";
    }

    public function getTemplateName()
    {
        return "AdminBundle:Home:login.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  84 => 40,  81 => 39,  57 => 18,  50 => 15,  44 => 13,  42 => 12,  32 => 4,  29 => 3,);
    }
}
